module Dft
  ( dftMat
  )
where

import qualified Data.Complex                  as C
import qualified Data.Matrix                   as M
import qualified Data.Vector                   as V
import qualified Numeric.LinearAlgebra.Data    as LA
import           Data.List

omega :: Int -> C.Complex Float
omega n = C.mkPolar 1 (2 * pi / (fromIntegral n))

omegaPn :: Int -> Int -> C.Complex Float
omegaPn p = (** (fromIntegral p)) . omega

sqId :: Int -> [(Int, Int)]
sqId n = [ (i, j) | i <- [0 .. n - 1], j <- [0 .. n - 1] ]

dftMat :: Int -> M.Matrix (C.Complex Float)
dftMat n = (M.scaleMatrix . ((/) 1) . sqrt . fromIntegral) n
  $ M.fromList n n [ omegaPn (i * j) n | (i, j) <- sqId n ]

dft :: V.Vector (C.Complex Float) -> V.Vector (C.Complex Float)
dft x = w * x where w = dftMat (V.length x)
