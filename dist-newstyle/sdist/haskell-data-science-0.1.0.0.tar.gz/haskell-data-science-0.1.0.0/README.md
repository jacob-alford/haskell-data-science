# haskell-data-science

A simple repository to adapt data-science imperative algorithms into functional ones
