# Changelog for haskell-data-science

## Unreleased changes
